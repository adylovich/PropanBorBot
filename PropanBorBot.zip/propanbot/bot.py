import asyncio, json, math, os
from aiogram import Bot, Dispatcher, F
from aiogram.types import (Message, KeyboardButton, ReplyKeyboardMarkup,
                            ReplyKeyboardRemove, InlineKeyboardMarkup,
                            InlineKeyboardButton)
from aiogram.filters import CommandStart, Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage

TOKEN = os.getenv("BOT_TOKEN", "YOUR_TOKEN_HERE")
bot = Bot(token=TOKEN)
dp  = Dispatcher(storage=MemoryStorage())

# ---------- AZS ma'lumotlarini yuklash ----------
with open("azs.json", encoding="utf-8") as f:
    AZS_LIST = json.load(f)

def haversine(lat1, lon1, lat2, lon2):
    R = 6371
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = math.sin(dlat/2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon/2)**2
    return R * 2 * math.asin(math.sqrt(a))

def save_azs():
    with open("azs.json", "w", encoding="utf-8") as f:
        json.dump(AZS_LIST, f, ensure_ascii=False, indent=2)

# ---------- Klaviaturalar ----------
def main_menu():
    return ReplyKeyboardMarkup(keyboard=[
        [KeyboardButton(text="📍 Yaqin AZS topish", request_location=True)],
        [KeyboardButton(text="📋 Barcha AZSlar"),   KeyboardButton(text="💰 Narxlar")],
        [KeyboardButton(text="➕ AZS qo'shish"),    KeyboardButton(text="✏️ Narx yangilash")],
        [KeyboardButton(text="ℹ️ Yordam")]
    ], resize_keyboard=True)

# ---------- FSM holatlari ----------
class AddAZS(StatesGroup):
    name     = State()
    location = State()
    price    = State()
    hours    = State()
    phone    = State()
    region   = State()

class UpdatePrice(StatesGroup):
    choose = State()
    price  = State()

# ---------- /start ----------
@dp.message(CommandStart())
async def cmd_start(msg: Message, state: FSMContext):
    await state.clear()
    await msg.answer(
        "⛽ *PropanBorBot ga xush kelibsiz!*\n\n"
        "Bu bot Toshkent va viloyatidagi propan AZSlari haqida ma'lumot beradi.\n\n"
        "📍 Lokatsiyangizni yuboring — eng yaqin AZSni topamiz!\n"
        "Ma'lumotlar foydalanuvchilar tomonidan yangilanib boradi.",
        parse_mode="Markdown",
        reply_markup=main_menu()
    )

# ---------- Lokatsiya → Yaqin AZSlar ----------
@dp.message(F.location)
async def nearest_azs(msg: Message):
    ulat, ulng = msg.location.latitude, msg.location.longitude
    with_coords = [a for a in AZS_LIST if a.get("lat") and a.get("lng")]
    ranked = sorted(with_coords, key=lambda a: haversine(ulat, ulng, a["lat"], a["lng"]))[:5]

    text = "📍 *Sizga eng yaqin AZSlar:*\n\n"
    for i, a in enumerate(ranked, 1):
        dist = haversine(ulat, ulng, a["lat"], a["lng"])
        dist_str = f"{dist*1000:.0f}м" if dist < 1 else f"{dist:.1f}km"
        status_icon = "🟢" if a["status"] == "Ochiq" else "🔴" if a["status"] == "Yopiq" else "⚪"
        price_str = f"{a['price']:,} so'm".replace(",", " ") if a.get("price") else "Noma'lum"
        hours_str = a.get("hours", "—")
        phone_str = f"\n📞 {a['phone']}" if a.get("phone") else ""
        text += (
            f"{i}. {status_icon} *{a['name']}*\n"
            f"   📏 {dist_str} | 💰 {price_str} | 🕐 {hours_str}"
            f"{phone_str}\n\n"
        )

    # Inline lokatsiya tugmalari
    buttons = []
    for a in ranked:
        buttons.append([InlineKeyboardButton(
            text=f"🗺 {a['name']}",
            url=a.get("url", f"https://maps.google.com/?q={a['lat']},{a['lng']}")
        )])
    kb = InlineKeyboardMarkup(inline_keyboard=buttons)
    await msg.answer(text, parse_mode="Markdown", reply_markup=kb)

# ---------- Barcha AZSlar ----------
@dp.message(F.text == "📋 Barcha AZSlar")
async def all_azs(msg: Message):
    shahar   = [a for a in AZS_LIST if a.get("region") == "Toshkent shahar"]
    viloyat  = [a for a in AZS_LIST if a.get("region") == "Toshkent viloyati"]

    def fmt(lst):
        lines = []
        for a in lst:
            s = "🟢" if a["status"]=="Ochiq" else "🔴" if a["status"]=="Yopiq" else "⚪"
            p = f"{a['price']:,}".replace(",", " ") if a.get("price") else "—"
            lines.append(f"{s} {a['name']} — {p} so'm")
        return "\n".join(lines)

    text = (
        f"⛽ *Toshkent shahri ({len(shahar)} ta):*\n{fmt(shahar)}\n\n"
        f"🌆 *Toshkent viloyati ({len(viloyat)} ta):*\n{fmt(viloyat)}"
    )
    await msg.answer(text, parse_mode="Markdown")

# ---------- Narxlar ----------
@dp.message(F.text == "💰 Narxlar")
async def prices(msg: Message):
    sorted_azs = sorted([a for a in AZS_LIST if a.get("price")], key=lambda x: x["price"])
    text = "💰 *Narxlar (arzondan qimmatga):*\n\n"
    for a in sorted_azs:
        s = "🟢" if a["status"]=="Ochiq" else "🔴" if a["status"]=="Yopiq" else "⚪"
        text += f"{s} {a['price']:,} so'm — {a['name']}\n".replace(",", " ")
    await msg.answer(text, parse_mode="Markdown")

# ---------- Yordam ----------
@dp.message(F.text == "ℹ️ Yordam")
async def help_cmd(msg: Message):
    await msg.answer(
        "ℹ️ *PropanBorBot — Yordam*\n\n"
        "📍 *Yaqin AZS* — lokatsiyangizni yuboring\n"
        "📋 *Barcha AZSlar* — to'liq ro'yxat\n"
        "💰 *Narxlar* — narxlar ro'yxati\n"
        "➕ *AZS qo'shish* — yangi AZS qo'shing\n"
        "✏️ *Narx yangilash* — joriy narxni yangilang\n\n"
        "⚡ Ma'lumotlar foydalanuvchilar tomonidan yangilanadi.\n"
        "🤝 Siz ham yangi AZS yoki narx qo'shib yordam bering!",
        parse_mode="Markdown"
    )

# ---------- AZS qo'shish ----------
@dp.message(F.text == "➕ AZS qo'shish")
async def add_start(msg: Message, state: FSMContext):
    await state.set_state(AddAZS.name)
    await msg.answer("✏️ AZS nomini kiriting:\n(masalan: Sergeli 3, Yunusobod 5)", reply_markup=ReplyKeyboardRemove())

@dp.message(AddAZS.name)
async def add_name(msg: Message, state: FSMContext):
    await state.update_data(name=msg.text)
    await state.set_state(AddAZS.location)
    await msg.answer("📍 AZS lokatsiyasini yuboring:", reply_markup=ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text="📍 Lokatsiya yuborish", request_location=True)]],
        resize_keyboard=True))

@dp.message(AddAZS.location, F.location)
async def add_location(msg: Message, state: FSMContext):
    await state.update_data(lat=msg.location.latitude, lng=msg.location.longitude)
    await state.set_state(AddAZS.price)
    await msg.answer("💰 Narxni kiriting (so'mda):\n(masalan: 6700)", reply_markup=ReplyKeyboardRemove())

@dp.message(AddAZS.price)
async def add_price(msg: Message, state: FSMContext):
    try:
        price = int(msg.text.replace(" ", "").replace(",", ""))
        await state.update_data(price=price)
        await state.set_state(AddAZS.hours)
        await msg.answer("🕐 Ish vaqtini kiriting:\n(masalan: 08:00-22:00 yoki 24/7)",
            reply_markup=ReplyKeyboardMarkup(
                keyboard=[[KeyboardButton(text="24/7")]],
                resize_keyboard=True))
    except:
        await msg.answer("❌ Faqat raqam kiriting. Masalan: 6700")

@dp.message(AddAZS.hours)
async def add_hours(msg: Message, state: FSMContext):
    await state.update_data(hours=msg.text)
    await state.set_state(AddAZS.phone)
    await msg.answer("📞 Telefon raqam (ixtiyoriy):\nYo'q bo'lsa — /skip yozing",
        reply_markup=ReplyKeyboardRemove())

@dp.message(AddAZS.phone)
async def add_phone(msg: Message, state: FSMContext):
    phone = "" if msg.text == "/skip" else msg.text
    await state.update_data(phone=phone)
    await state.set_state(AddAZS.region)
    await msg.answer("🌆 Hudud:", reply_markup=ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="Toshkent shahar")],
            [KeyboardButton(text="Toshkent viloyati")]
        ], resize_keyboard=True))

@dp.message(AddAZS.region)
async def add_region(msg: Message, state: FSMContext):
    data = await state.get_data()
    new_azs = {
        "id": f"user_{len(AZS_LIST)+1}",
        "name": data["name"],
        "price": data["price"],
        "status": "Ochiq",
        "hours": data["hours"],
        "phone": data.get("phone", ""),
        "region": msg.text,
        "lat": data["lat"],
        "lng": data["lng"],
        "url": f"https://maps.google.com/?q={data['lat']},{data['lng']}",
        "note": f"Qo'shdi: @{msg.from_user.username or msg.from_user.id}"
    }
    AZS_LIST.append(new_azs)
    save_azs()
    await state.clear()
    await msg.answer(
        f"✅ *{data['name']}* qo'shildi!\n"
        f"💰 {data['price']:,} so'm | 🕐 {data['hours']}".replace(",", " "),
        parse_mode="Markdown", reply_markup=main_menu())

# ---------- Narx yangilash ----------
@dp.message(F.text == "✏️ Narx yangilash")
async def update_start(msg: Message, state: FSMContext):
    await state.set_state(UpdatePrice.choose)
    buttons = [[InlineKeyboardButton(text=f"⛽ {a['name']}", callback_data=f"upd_{i}")]
               for i, a in enumerate(AZS_LIST)]
    kb = InlineKeyboardMarkup(inline_keyboard=buttons)
    await msg.answer("Qaysi AZS narxini yangilaysiz?", reply_markup=kb)

from aiogram.types import CallbackQuery

@dp.callback_query(F.data.startswith("upd_"))
async def choose_azs(call: CallbackQuery, state: FSMContext):
    idx = int(call.data.split("_")[1])
    await state.update_data(idx=idx)
    await state.set_state(UpdatePrice.price)
    await call.message.answer(f"💰 *{AZS_LIST[idx]['name']}* uchun yangi narx (so'm):",
        parse_mode="Markdown", reply_markup=ReplyKeyboardRemove())
    await call.answer()

@dp.message(UpdatePrice.price)
async def update_price(msg: Message, state: FSMContext):
    try:
        data = await state.get_data()
        idx  = data["idx"]
        old  = AZS_LIST[idx].get("price", 0)
        new  = int(msg.text.replace(" ","").replace(",",""))
        AZS_LIST[idx]["price"] = new
        save_azs()
        await state.clear()
        arrow = "📈" if new > old else "📉" if new < old else "➡️"
        await msg.answer(
            f"✅ Narx yangilandi!\n"
            f"⛽ *{AZS_LIST[idx]['name']}*\n"
            f"{arrow} {old:,} → {new:,} so'm".replace(",", " "),
            parse_mode="Markdown", reply_markup=main_menu())
    except:
        await msg.answer("❌ Faqat raqam kiriting. Masalan: 6800")

# ---------- Ishga tushirish ----------
async def main():
    print("PropanBorBot ishga tushdi ✅")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())

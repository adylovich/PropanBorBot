# PropanBorBot

## O'rnatish

```bash
pip install -r requirements.txt
```

## Ishga tushirish

```bash
export BOT_TOKEN=your_token_here
python bot.py
```

## Railway ga deploy qilish
1. railway.app ga kiring
2. New Project → Deploy from GitHub
3. Variables ga BOT_TOKEN qo'shing
4. Deploy!
